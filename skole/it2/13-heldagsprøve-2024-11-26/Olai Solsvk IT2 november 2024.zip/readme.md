# Olai Solsvik - Heldsgsprøve IT2, 2024-11-26

Jeg fokuserte ikke veldig mye på å kommentere kode, men prøvde heller å skrive god kode på den tiden jeg har, forhåpentligvis god nok til å være leselig uten mange kommentarer.

## Egne notater

Zip-command så jeg husker den til senere:

```sh
nix run nixpkgs#zip -- -r "Olai Solsvik IT2 november 2024" ./*
```
