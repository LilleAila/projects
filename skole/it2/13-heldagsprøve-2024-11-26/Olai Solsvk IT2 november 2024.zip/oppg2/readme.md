# Oppgave 2

`v1`: Enkel løsning med kun en plass
`v2`: Lagt til tid
`v3`: Parkeringshus med flere plasser
`v4`: TUI + Skikkelig innkapsling med getters / setters (hvis jeg får tid)
`klassediagram.png`: UML-diagram over klasser

I all koden har jeg valgt å printe direkte mange steder, heller enn å returnere stringer eller data fra funksjonen. Dette er et valg jeg har tatt for at koden skal være nærmere det oppgaven spør om. (ser på bildet med bruk av API-en)
