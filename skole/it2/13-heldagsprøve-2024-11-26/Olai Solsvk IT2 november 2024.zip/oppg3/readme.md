# Pygame - KlikkKlikkKlikk

`v1`: Enkel løsning på oppgave 1 som teller sekunder og viser poeng.
`v2`: Flere runder, som i oppgave 2.
`v3`: Kollisjon med rektangel, og flytte tilfeldig.
`flytskjema.png` og `klassediagram.png`: UML-diagrammer.

Mulige forbedringer:
Legge til knapper slik at spilleren kan trykke, heller enn at alt skjer av seg selv.
