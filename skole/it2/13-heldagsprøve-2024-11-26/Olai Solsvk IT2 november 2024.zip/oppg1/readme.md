# Oppgave 1

BMI-kalkulator. Løsning i `main.py` og `main.png`

`main.png`: flytskjema

## 1.f

Jeg valgte å også implementere en sjekk for om tallet man skriver inn er mer enn 0. I tillegg gjorde jeg at man også kan avslutte ved å svare ingenting på vekten. En mulig feil som ikke er håndtert er `KeyboardInterrupt` og `EOFError`, i tillegg til at det ikke er noen øvre grense for vekt og høyde.
